//
//  AppDelegate.h
//  Moments
//
//  Created by CF_Dasi on 2021/3/8.
//  Copyright © 2021年 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(strong,nonatomic) NSMutableArray *newpost;
@property(assign,nonatomic) int fileCount;
@property(assign,nonatomic) int cellID;
@property(assign,nonatomic) BOOL isPlaying;
@end

