//
//  cellModel.h
//  Moments
//
//  Created by jingrun lin on 2021/3/9.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface cellModel : NSObject

@property(nonatomic,strong) NSString* content;
@property(nonatomic,strong) NSString* userTime;
@property(nonatomic,strong) NSString* userName;
@property(nonatomic,strong) NSString* imgName;

@property(nonatomic,strong) NSArray* img;
@property(nonatomic,strong) NSString* filePath;
@property(nonatomic,strong) NSString* audioWords;
@property(nonatomic,assign) float audioTime;

-(instancetype) initWithDic:(NSDictionary *)dic;
+(instancetype) cellModelWithDic:(NSDictionary *)dic;

@end

NS_ASSUME_NONNULL_END
