//
//  cellModel.m
//  Moments
//
//  Created by jingrun lin on 2021/3/9.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import "cellModel.h"

@implementation cellModel

- (instancetype) initWithDic:(NSDictionary *)dic{
    if (self = [super init]){
        [self setValuesForKeysWithDictionary:dic];
    }
    
    return self;
}
    
+ (instancetype) cellModelWithDic:(NSDictionary *)dic{
    return [[cellModel alloc] initWithDic:dic];}


@end
