//
//  ImgGestureRecognizer.h
//  Moments
//
//  Created by jingrun lin on 2021/3/11.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ImgGestureRecognizer : UITapGestureRecognizer

@property(strong,nonatomic) UIImage* tapImg;
@property(strong,nonatomic) NSString* audioPath;

@end

NS_ASSUME_NONNULL_END
