//
//  ImgGestureRecognizer.m
//  Moments
//
//  Created by jingrun lin on 2021/3/11.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import "ImgGestureRecognizer.h"

@implementation ImgGestureRecognizer

@end



