//
//  EditViewController.m
//  Moments
//
//  Created by jingrun lin on 2021/3/10.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import "EditViewController.h"
#import "MomentsViewController.h"
#import "DragViewController.h"

#import "selectPicView.h"
#import "AudioView.h"
#import "Nav.h"
#import "OptionsCell.h"
#import "SpectrumView.h"

#import "cellModel.h"
#import "AppDelegate.h"
#import "Masonry.h"

#define lightGreenColor colorWithRed:179.0f/255.0f green:230.0f/255.0f blue:179.0f/255.0f alpha:0.80
#define lightBlueColor colorWithRed:128.0f/255.0f green:223.0f/255.0f blue:255.0f/255.0f alpha:0.75
#define ScreenBounds           [[UIScreen mainScreen] bounds].size
#define ScreenW                 ScreenBounds.width
#define ScreenH                 ScreenBounds.height

#define APP_DOCUMENT                [NSSearchPathForDirectoriesInDomains (NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]
#define DocumentPath(path)          [APP_DOCUMENT stringByAppendingPathComponent:path]

@interface EditViewController ()

@property(nonatomic,strong) Nav* navView;
@property(nonatomic,strong) AudioView* audioView;
@property(nonatomic,strong) UITextView* textView;
@property(nonatomic,strong) UITableView* infoTableView;

@property(nonatomic,strong) UIView* recordingView;
@property(nonatomic,strong) NSMutableArray* infoArray;
@property(nonatomic,strong) SpectrumView* spectrumView;

@end

@implementation EditViewController

#pragma mark - ViewLifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initData];
    _selectedArray = [[NSMutableArray alloc] init];
    _selectedFilePath = [[NSMutableArray alloc] init];
    [_selectedArray addObject:_selectedPic1];
    
    [self.view addSubview:self.picSelect];
    [self addPicwithNum:0];
    [self.view addSubview:self.navView];
    [self.view addSubview:self.textView];
    [self.view addSubview:self.infoTableView];
    [self.view addSubview:self.audioView];
    [self.view setBackgroundColor:[UIColor lightBlueColor]];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(openKeyboard:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(closeKeyboard:) name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark - initData

-(void)initData
{
    _infoArray = [NSMutableArray array];
    NSMutableArray * arr = [[NSMutableArray alloc] initWithObjects:
                            @{@"userName":@"所在位置",@"imgName":@"cell"
                            },@{
                                @"userName":@"提醒谁看",@"imgName":@"cell"
                            },@{
                                @"userName":@"文件管理(未完成)",@"imgName":@"cell"
                            }, nil];

    for(NSInteger j = 0;j < arr.count;j++) {
        NSDictionary * dic =arr[j];
        cellModel *model = [[cellModel alloc]init];
        model.userName = dic[@"userName"];
        model.imgName = dic[@"imgArr"];
        [self.infoArray addObject:model];
    }
}

#pragma mark - audioViewDelagate

-(void)startRecord
{
    __weak EditViewController *weakSelf = self;
    self.spectrumView = [[SpectrumView alloc] initWithFrame:CGRectMake(0,ScreenH/2-60,ScreenW, 40.0)];
    __weak SpectrumView * weakSpectrum = self.spectrumView;
    
    self.spectrumView.itemLevelCallback = ^() {
        [weakSelf.audioView.audioRecorder updateMeters];
        float power= [weakSelf.audioView.audioRecorder averagePowerForChannel:0];
        weakSpectrum.level = power;
    };
    
    [self.view addSubview:self.spectrumView];
    [self.spectrumView start];
    _recordingView = [[UIView alloc] init];
    _recordingView.frame = CGRectMake(0, ScreenH/2, ScreenW, ScreenH/2);
    
    UIColor *color = [UIColor lightGreenColor];
    color = [color colorWithAlphaComponent:0.5];
    _recordingView.backgroundColor = color;
    [self.view addSubview:_recordingView];
}

-(void)endRecord
{
    [self.spectrumView stop];
    [self.recordingView removeFromSuperview];
    [self.spectrumView removeFromSuperview];
}

#pragma mark - selectPicViewDelegate

-(void)addPicBtnOnClick
{
    [self creatActionSheet];
    [self.picSelect reloadInputViews];
}

#pragma mark - infoTableView Delegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 2) {
        DragViewController *v2 = [[DragViewController alloc]init];
        v2.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:v2 animated:YES completion:nil];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OptionsCell* cell = [OptionsCell cellWithTableView:_infoTableView withIndexPath:indexPath];
    cellModel *model = [[cellModel alloc]init];
    model = self.infoArray[indexPath.row];
    cell.cellName.text = model.userName;
    
    [cell.cellImage setImage:[UIImage imageNamed:model.imgName] forState:UIControlStateNormal];
    return cell;
}

#pragma mark - navigation Delegate

-(void)navRightClick
{
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy年MM月dd日 HH:mm";
    NSString *time = [formatter stringFromDate:[NSDate date]];
    
    
    NSString *path_document = NSHomeDirectory();
    for(int i = 0;i<self.selectedArray.count;i++)
    {
        NSString* symbol =[NSString stringWithFormat:@"/Documents/%luandSelectedNum:%dpic.png",(unsigned long)app.newpost.count,i];
        NSString*filePath = [path_document stringByAppendingPathComponent:symbol];
    [UIImagePNGRepresentation(self.selectedArray[i]) writeToFile:filePath atomically:YES];
        [self.selectedFilePath addObject:filePath];
    }

    NSMutableDictionary * dic = [[NSMutableDictionary alloc] initWithDictionary:
                              @{@"userName":@"霞",
                                @"imgName":@"avatar7",
                                @"userTime":time,
                                @"content":self.textView.text,
                                
                                @"img":self.selectedFilePath,
                                @"filePath":self.audioView.theFilePath,
                                @"audioTime":[NSNumber numberWithFloat:self.audioView.audioTime]
                              }];
    
    
    
    
    [app.newpost insertObject:dic atIndex:0];
    NSData *resultData = [NSJSONSerialization dataWithJSONObject:app.newpost options:NSJSONWritingPrettyPrinted error:nil];
    [resultData writeToFile:DocumentPath(@"localData.plist") atomically:YES];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)navLeftClick
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Keyboard

- (void)openKeyboard:(NSNotification *)notification{}

-(void)closeKeyboard:(NSNotification *)notification{}

- (void)touchesBegan:(NSSet<UITouch *> *)touches   withEvent:(UIEvent *)event
{
      [self.view endEditing:YES];
}

- (void)dealloc
{
      [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

-(void)creatActionSheet {

    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction *actionCamera = [UIAlertAction actionWithTitle:@"拍摄" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
            imagePickerController.delegate = self;

            imagePickerController.allowsEditing = NO;
            imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceRear;
            [self presentViewController:imagePickerController animated:YES completion:nil];
    }];
    
    UIAlertAction *actionPhoto = [UIAlertAction actionWithTitle:@"从相册选择图片或视频" style:UIAlertActionStyleDefault handler:  ^(UIAlertAction * _Nonnull action){
                                  UIImagePickerController *picker = [[UIImagePickerController alloc] init];
                                  picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                  picker.delegate = self;
                                  picker.allowsEditing = NO;
        [self presentViewController:picker animated:YES completion:nil];}];
    
    UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [actionSheet addAction:actionCamera];
    [actionSheet addAction:actionPhoto];
    [actionSheet addAction:actionCancel];
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}

#pragma mark - UIImagePickerController Delegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    [picker dismissViewControllerAnimated:YES completion:nil];
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    [_selectedArray addObject:image];
    [self addPicwithNum:_selectedArray.count-1];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)addPicwithNum:(unsigned long)i
{
    UIImageView *newImage = [[UIImageView alloc] init];
    [self.picSelect addSubview:newImage];
    [newImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(newImage.superview.mas_right).offset(10+i*85);
        make.top.equalTo(newImage.superview.mas_top).offset(10);
        make.size.mas_equalTo(CGSizeMake(75, 75));
    }];
    
    newImage.layer.cornerRadius = 15.0f;
    newImage.layer.masksToBounds = YES;
    newImage.image = _selectedArray[i];
    self.picSelect.picCount++;
    [self.picSelect updateLocationOfAddPicBtn];
}
#pragma mark - getter and setter

-(selectPicView*)picSelect
{
    if(!_picSelect)
    {
        _picSelect = [[selectPicView alloc] initWithFrame:CGRectMake(30, 370, [UIScreen mainScreen].bounds.size.width-60, 95)];
        _picSelect.scrollEnabled = YES;
        _picSelect.picCount = 0;
        [_picSelect.addPicBtn addTarget:self action:@selector(addPicBtnOnClick) forControlEvents:UIControlEventTouchUpInside];
        
        _picSelect.layer.cornerRadius = 15.0f;
        _picSelect.layer.masksToBounds = YES;
        _picSelect.backgroundColor = [UIColor whiteColor];
    }
    return _picSelect;
}

-(Nav*)navView
{
    if(!_navView){
        _navView = [[Nav alloc] initWithFrame:CGRectMake(0, -30, [UIScreen mainScreen].bounds.size.width, 150)];
        _navView.middleTitleLab.text = @"发表文字";
        _navView.rightBtn.backgroundColor = [UIColor colorWithRed:1.0f/255.0f green:223.0f/255.0f blue:1.0f/255.0f alpha:0.95];
        
        
        [_navView.rightBtn setTitle:@"发表" forState:UIControlStateNormal];
        _navView.rightBtn.frame = CGRectMake([UIScreen mainScreen].bounds.size.width - 75 ,63 , 50, 30 );
        [_navView.rightBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _navView.delegate = self;
    }
    return _navView;
}

-(UITableView*)infoTableView
{
    if(!_infoTableView)
    {
        _infoTableView = [[UITableView alloc] initWithFrame:CGRectMake(30, 470, [UIScreen mainScreen].bounds.size.width-60, 150) style:UITableViewStylePlain];
        _infoTableView.dataSource = self;
        _infoTableView.delegate = self;
        _infoTableView.backgroundColor = [UIColor whiteColor];
        
        _infoTableView.layer.cornerRadius = 15.0f;
        _infoTableView.layer.masksToBounds = YES;
    }
    return _infoTableView;
}

-(AudioView*)audioView
{
    if (!_audioView) {
        _audioView = [[AudioView alloc] initWithFrame:CGRectMake(30, 300, [UIScreen mainScreen].bounds.size.width-60, 70)];
        _audioView.mydelegate = self;
        
    }
    return _audioView;
}

-(UITextView*)textView
{
    if(!_textView)
    {
        _textView = [[UITextView alloc] initWithFrame:CGRectMake(30, 80, [UIScreen mainScreen].bounds.size.width-60, 200)];
        _textView.font = [UIFont systemFontOfSize:20];
        _textView.backgroundColor = [UIColor whiteColor];
        _textView.keyboardType = UIKeyboardTypeDefault;
        
        _textView.layer.cornerRadius = 15.0f;
        _textView.layer.masksToBounds = YES;
    }
    return _textView;
}
@end
    
    
