//
//  FileCell.h
//  Moments
//
//  Created by jingrun lin on 2021/3/12.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CellAudio.h"

@protocol fileCellDelegate <NSObject>

-(void)changeSelectArray:(NSString *_Nullable)text;
-(void)setCellToTop:(NSString *_Nullable)text;
@end

NS_ASSUME_NONNULL_BEGIN

@interface FileCell : UITableViewCell

@property(nonatomic,weak)id<fileCellDelegate> delegate;
@property(nonatomic,strong) UILabel* fileName;
@property(nonatomic,strong) UIButton* moveToTop;
@property(nonatomic,strong) UIButton* pressMove;
@property(nonatomic,strong) CellAudio* audioView;
@property(nonatomic,strong) UIButton* selectBtn;
@property(nonatomic,assign) BOOL isSelected;

+(instancetype)cellWithTableView:(UITableView *)tableView withIndexPath:(NSIndexPath*)indexPath;
@end

NS_ASSUME_NONNULL_END
