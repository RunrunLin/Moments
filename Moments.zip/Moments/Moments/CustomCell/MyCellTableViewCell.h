//
//  MyCellTableViewCell.h
//  Moments
//
//  Created by CF_Dasi on 2021/3/8.
//  Copyright © 2021年 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CellAudio.h"

NS_ASSUME_NONNULL_BEGIN




@interface MyCellTableViewCell : UITableViewCell

@property(nonatomic,strong) UIButton *cellImage;
@property(nonatomic,strong) UIView *imagePlace;
@property(nonatomic,strong) UIScrollView *imageScroll;
@property(nonatomic,strong) UILabel *cellName;

@property(nonatomic,strong) UILabel *cellText;
@property(nonatomic,strong) UILabel *cellTime;
@property(nonatomic,strong) UILabel *audioWords;
@property(nonatomic,strong) NSMutableArray *cellImgArr;

@property(nonatomic,strong) CellAudio* cellAudio;
@property(nonatomic,strong) UIButton* deleteBtn;

+(instancetype)cellWithTableView:(UITableView *)tableView withIndexPath:(NSIndexPath*)indexPath;

@end

NS_ASSUME_NONNULL_END
