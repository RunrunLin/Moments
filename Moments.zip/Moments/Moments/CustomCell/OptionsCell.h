//
//  OptionsCell.h
//  Moments
//
//  Created by jingrun lin on 2021/3/24.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OptionsCell : UITableViewCell

@property(nonatomic,strong) UIButton *cellImage;
@property(nonatomic,strong) UILabel *cellName;
+(instancetype)cellWithTableView:(UITableView *)tableView withIndexPath:(NSIndexPath*)indexPath;

@end

NS_ASSUME_NONNULL_END
