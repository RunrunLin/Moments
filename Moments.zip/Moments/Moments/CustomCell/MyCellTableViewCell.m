//
//  MyCellTableViewCell.m
//  Moments
//
//  Created by CF_Dasi on 2021/3/8.
//  Copyright © 2021年 JIAYZ. All rights reserved.
//

#import "MyCellTableViewCell.h"
#import "cellModel.h"
#import "ImgGestureRecognizer.h"
#import "Masonry.h"
#define imageX 5
#define imageY 15
#define imageWidth 75
#define imageHeight 75
#define lightBlueColor colorWithRed:128.0f/255.0f green:223.0f/255.0f blue:255.0f/255.0f alpha:0.75

@implementation MyCellTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}
#pragma mark - init
+(instancetype)cellWithTableView:(UITableView *)tableView withIndexPath:(NSIndexPath*)indexPath
{
        static NSString *ID = @"cell";
        MyCellTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if(!cell)
    {
        cell = [[MyCellTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:ID];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return cell;
}
-(void)setFrame:(CGRect)frame
{
    frame.origin.x =4;//这里间距为10，可以根据自己的情况调整
    frame.size.width -=frame.origin.x;
    frame.size.height -= 5 * frame.origin.x;
    [super setFrame:frame];
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.layer.cornerRadius=40.0f;
        self.layer.masksToBounds=YES;
        [self initCell];
        [self masonryLayout];
    }
    return self;
}
-(void)initCell{
    //cellImage
    _cellImage = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.contentView addSubview:self.cellImage];
    //cellName
    _cellName = [[UILabel alloc] init];
    [self.contentView addSubview:self.cellName];
    
    //cellText
    _cellText = [[UILabel alloc] init];
    [self.contentView addSubview:self.cellText];
    
    //imageScroll
    _imageScroll = [[UIScrollView alloc] init];
    [self addSubview:self.imageScroll];
    
    //cellTime
    _cellTime = [[UILabel alloc] init];
    [self addSubview:self.cellTime];
    
    _cellAudio = [[CellAudio alloc] init];
    [self addSubview:self.cellAudio];
    
    _audioWords = [[UILabel alloc] init];
    [self addSubview:self.audioWords];
    
    _deleteBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self addSubview:self.deleteBtn];
}

#pragma mark - Masonry

-(void)masonryLayout
{
    
#pragma mark - cellImage
    
    [_cellImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_cellImage.superview).offset(5);
        make.top.equalTo(self->_cellImage.superview).offset(20);
        make.size.mas_equalTo(CGSizeMake(60, 60));
    }];
    self.cellImage.layer.cornerRadius=30.0f;
    self.cellImage.layer.masksToBounds=YES;
    
#pragma mark - cellName
    
    [_cellName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self->_cellName.superview).offset(20);
        make.left.equalTo(self->_cellImage.mas_right).offset(20);
        make.size.mas_equalTo(CGSizeMake(150, 20));
    }];
    _cellName.textColor = [UIColor blueColor];
    _cellName.font = [UIFont systemFontOfSize:18];
    
#pragma mark - cellText
    
    [_cellText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self->_cellName.mas_bottom).offset(10);
        make.left.equalTo(self->_cellImage.mas_right).offset(20);
    }];
    _cellText.font = [UIFont systemFontOfSize:16];
    _cellText.numberOfLines = 0;
    _cellText.preferredMaxLayoutWidth = 200;
    [_cellText setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    
#pragma mark - imagePlace
    
//    [_imagePlace mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self->_cellText.mas_bottom).offset(20);
//        make.left.equalTo(self->_cellImage.mas_right).offset(20);
//        make.bottom.equalTo(self.mas_bottom).offset(-100);
//        make.size.mas_equalTo(CGSizeMake([UIScreen mainScreen].bounds.size.width - 85, 120));
//    }];
    
    [_imageScroll mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self->_cellText.mas_bottom).offset(20);
        make.left.equalTo(self->_cellImage.mas_right).offset(20);
        make.bottom.equalTo(self.mas_bottom).offset(-100);
        make.size.mas_equalTo(CGSizeMake([UIScreen mainScreen].bounds.size.width - 85, 120));
    }];
    _imageScroll.scrollEnabled = YES;
    _imageScroll.showsHorizontalScrollIndicator = NO;
    
    
#pragma mark - CellAudio
    [_cellAudio mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self->_imageScroll.mas_bottom).offset(10);
        make.left.equalTo(self->_cellImage.mas_right).offset(20);
        make.size.mas_equalTo(CGSizeMake(200, 30));
    }];

    
#pragma mark - audioWords
    [_audioWords mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self->_cellAudio.mas_bottom).offset(0);
        make.left.equalTo(self->_cellImage.mas_right).offset(60);
        make.size.mas_equalTo(CGSizeMake(220, 20));
    }];
    _audioWords.textColor = [UIColor blackColor];
    _audioWords.font = [UIFont fontWithName:@"MFJinHei_Noncommercial-Regular" size:18];
    
#pragma mark - cellTime
    
    [_cellTime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self->_cellTime.superview.mas_bottom).offset(-10);
        make.left.equalTo(self->_cellImage.mas_right).offset(20);
        make.size.mas_equalTo(CGSizeMake(220, 20));
    }];
    _cellTime.textColor = [UIColor lightGrayColor];
    _cellTime.font = [UIFont systemFontOfSize:16];
    
#pragma mark - cellDelete
    
    [_deleteBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.mas_right).offset(85);
        make.top.equalTo(self->_cellText.mas_bottom).offset(0);
        make.size.mas_equalTo(CGSizeMake(80, 150));
    }];
    
    self.deleteBtn.layer.cornerRadius = 15.0f;
    self.deleteBtn.layer.masksToBounds = YES;
    [_deleteBtn setTitle:@"删\n除" forState:UIControlStateNormal];
    [_deleteBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    _deleteBtn.titleLabel.numberOfLines = 0;
    _deleteBtn.titleLabel.font = [UIFont fontWithName:@"MFJinHei_Noncommercial-Regular" size:24];
    _deleteBtn.hidden = YES;
    _deleteBtn.backgroundColor = [UIColor redColor];
    

}
//-(void)onClickDeleteBtn
//{
//    if (self.delegate &&[self.delegate respondsToSelector:@selector(deleteACell:event:)]) {
//        [self.delegate deleteACell:_deleteBtn event:<#(nonnull UIEvent *)#>];}
//}
    
@end
