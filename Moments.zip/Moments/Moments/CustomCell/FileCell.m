//
//  FileCell.m
//  Moments
//
//  Created by jingrun lin on 2021/3/12.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import "FileCell.h"
#import "Masonry.h"

@implementation FileCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
#pragma mark - init
+(instancetype)cellWithTableView:(UITableView *)tableView withIndexPath:(NSIndexPath*)indexPath
{
        static NSString *ID = @"cell";
        FileCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if(!cell)
    {
        cell = [[FileCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:ID];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return cell;
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initCell];
        [self Masonry];
    }
    return self;
}
-(void)initCell
{
    _audioView = [[CellAudio alloc] init];
    [self .contentView addSubview:self.audioView];
    
    _fileName = [[UILabel alloc] init];
    [self.contentView addSubview:self.fileName];
    
    _moveToTop = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.contentView addSubview:self.moveToTop];
    
    _pressMove = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.contentView addSubview:self.pressMove];
    
    _selectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.contentView addSubview:self.selectBtn];
}
#pragma mark - getter and setter
-(void)Masonry
{
    [_fileName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(20);
        make.top.equalTo(self.mas_top).offset(20);
        make.size.mas_equalTo(CGSizeMake(200, 50));
    }];
    _fileName.font = [UIFont systemFontOfSize:18];
    
    [_moveToTop mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_fileName.mas_right).offset(30);
        make.top.equalTo(self.mas_top).offset(50);
        make.size.mas_equalTo(CGSizeMake(50, 50));
    }];
    [_moveToTop setImage:[UIImage imageNamed:@"StickTop"] forState:UIControlStateNormal];
    [_moveToTop addTarget:self action:@selector(fileToTop:) forControlEvents:UIControlEventTouchUpInside];
    
    [_pressMove mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_moveToTop.mas_right).offset(20);
        make.top.equalTo(self.mas_top).offset(20);
        make.size.mas_equalTo(CGSizeMake(50, 50));
    }];
    [_pressMove setImage:[UIImage imageNamed:@"dragIcon"] forState:UIControlStateNormal];
    
    [_selectBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(20);
        make.top.equalTo(self.mas_top).offset(20);
        make.size.mas_equalTo(CGSizeMake(50, 50));
    }];
    NSString *selectAllImgStr = _isSelected?@"selectIcon":@"noSelectIcon";
    [_selectBtn setImage:[UIImage imageNamed:selectAllImgStr] forState:UIControlStateNormal];
    [_selectBtn addTarget:self action:@selector(selectFile) forControlEvents:UIControlEventTouchUpInside];
    _selectBtn.hidden = YES;
    
    [_audioView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(20);
        make.top.equalTo(self.mas_top).offset(100);
        make.size.mas_equalTo(CGSizeMake(200, 30));
    }];
}

#pragma mark - clickEvent
-(void)selectFile
{
    NSString *text = _fileName.text;
    NSString *selectAllImgStr = _isSelected?@"selectIcon":@"noSelectIcon";
    [_selectBtn setImage:[UIImage imageNamed:selectAllImgStr] forState:UIControlStateNormal];
    _isSelected = !_isSelected;
    if (self.delegate &&[self.delegate respondsToSelector:@selector(changeSelectArray:)]) {
        [self.delegate changeSelectArray:text];
    }
}
-(void)fileToTop:(UIButton *)sender
{
    NSString *text = _fileName.text;
    if (self.delegate &&[self.delegate respondsToSelector:@selector(setCellToTop:)]) {
        [self.delegate setCellToTop:text];
}
}
@end
