//
//  OptionsCell.m
//  Moments
//
//  Created by jingrun lin on 2021/3/24.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import "OptionsCell.h"
#import "Masonry.h"

@implementation OptionsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

+(instancetype)cellWithTableView:(UITableView *)tableView withIndexPath:(NSIndexPath*)indexPath
{
        static NSString *ID = @"optioncell";
        OptionsCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if(!cell)
    {
        cell = [[OptionsCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:ID];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return cell;
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initCell];
        [self masonryLayout];
    }
    return self;
}
-(void)masonryLayout
{
    
#pragma mark - cellImage
    
    [_cellImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_cellImage.superview).offset(5);
        make.top.equalTo(self->_cellImage.superview).offset(20);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    
#pragma mark - cellName
    
    [_cellName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self->_cellName.superview).offset(5);
        make.left.equalTo(self->_cellImage.mas_right).offset(20);
        make.size.mas_equalTo(CGSizeMake(250, 30));
    }];
    _cellName.textColor = [UIColor blackColor];
    _cellName.font = [UIFont systemFontOfSize:18];
}
-(void)initCell{
    //cellImage
    _cellImage = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.contentView addSubview:self.cellImage];
    //cellName
    _cellName = [[UILabel alloc] init];
    [self.contentView addSubview:self.cellName];
}

@end
