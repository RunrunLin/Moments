//
//  EditNav.h
//  Moments
//
//  Created by jingrun lin on 2021/3/12.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol EditNavDelegate <NSObject>

@optional

-(void)navLeftClick;
-(void)navEditBtnClick;
-(void)navMiddleClick;
-(void)navRightClickQuit;
-(void)navRightClickFinish;

@end

@interface EditNav : UIView

@property(nonatomic,weak) id<EditNavDelegate> mydelegate;
@property(nonatomic,strong) UIView* navBackView;
@property(nonatomic,strong) UIButton* leftEditBtn;
@property(nonatomic,strong) UIButton* leftBtn;

@property(nonatomic,strong) UILabel* middleTitleLab;
@property(nonatomic,strong) UIButton* rightBtn;
@property(nonatomic,strong) UILabel* bottomLable1;
@property(nonatomic,strong) UILabel* bottomLable2;
@property(nonatomic,strong) UILabel* bottomLable3;

@end

NS_ASSUME_NONNULL_END
