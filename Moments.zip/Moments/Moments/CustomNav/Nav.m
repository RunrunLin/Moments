//
//  Nav.m
//  Moments
//
//  Created by jingrun lin on 2021/3/10.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import "Nav.h"

@implementation Nav

-(instancetype)initWithFrame:(CGRect)frame{
    if(self = [super initWithFrame:frame])
    {
        [self buildUI];
    }
    return self;
}

-(void)buildUI
{
    _navBackView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 100)];
    _navBackView.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.navBackView];
    
    _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _leftBtn.frame = CGRectMake(20, _navBackView.frame.size.height-40, 30, 30);
    [_leftBtn setImage:[UIImage imageNamed:@"back"] forState:0];
    [_leftBtn addTarget:self action:@selector(leftBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.leftBtn];

    
    _rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _rightBtn.frame = CGRectMake([UIScreen mainScreen].bounds.size.width - 20 - 30,_navBackView.frame.size.height - 40 , 30, 30);
    [_rightBtn addTarget:self action:@selector(rightBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.rightBtn];
    
    _middleTitleLab = [[UILabel alloc]initWithFrame:CGRectMake(0, _navBackView.frame.size.height - 40,[UIScreen mainScreen].bounds.size.width , 30)];
    _middleTitleLab.textAlignment = 1;
    _middleTitleLab.text = @"Moments";
    _middleTitleLab.font = [UIFont boldSystemFontOfSize:17];
    [self addSubview:_middleTitleLab];
    
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
    //长按时间
    longPress.minimumPressDuration = 0.5;
    [_rightBtn addGestureRecognizer:longPress];
}


- (void)rightBtnClick{
        if (self.delegate &&[self.delegate respondsToSelector:@selector(navRightClick)]) {
            [self.delegate navRightClick];
        }
}
- (void)leftBtnClick{
        if (self.delegate &&[self.delegate respondsToSelector:@selector(navLeftClick)]) {
            [self.delegate navLeftClick];
        }
}

- (void)longPress:(UILongPressGestureRecognizer*)gesture {
    if ( gesture.state == UIGestureRecognizerStateEnded ) {
        if (self.delegate &&[self.delegate respondsToSelector:@selector(navRightLongPress)]) {
            [self.delegate navRightLongPress];
        }
    }
}
@end
