//
//  EditNav.m
//  Moments
//
//  Created by jingrun lin on 2021/3/12.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import "EditNav.h"



@implementation EditNav


-(instancetype)initWithFrame:(CGRect)frame{
    if(self = [super initWithFrame:frame])
    {
        [self buildEditNavUI];
    }
    return self;
}

-(void)buildEditNavUI
{
    [self addSubview:self.navBackView];
    [self addSubview:self.leftBtn];
    [self addSubview:self.rightBtn];
    [self addSubview:self.middleTitleLab];
    [self addSubview:self.bottomLable1];
    [self addSubview:self.bottomLable2];
    [self addSubview:self.bottomLable3];
}
#pragma mark - getter
-(UIView*)navBackView
{
    if(!_navBackView)
    {
        _navBackView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 200)];
        _navBackView.backgroundColor = [UIColor colorWithRed:232.0f/255.0f green:232.0f/255.0f blue:232.0f/255.0f alpha:0.95];
        
    }
    return _navBackView;
}
-(UIButton*)leftBtn
{
    if(!_leftBtn)
    {
        _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftBtn.frame =CGRectMake(10, 35, 50, 50);
    [_leftBtn setImage:[UIImage imageNamed:@"dragIcon"] forState:UIControlStateNormal];
    [_leftBtn addTarget:self action:@selector(leftBtnClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _leftBtn;
}
-(UIButton*)rightBtn
{
    if(!_rightBtn)
    {
        _rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _rightBtn.frame =CGRectMake(310, 35, 50, 50);
        [_rightBtn setTitle:@"完成" forState:UIControlStateNormal];
        [_rightBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _rightBtn.titleLabel.font = [UIFont systemFontOfSize:18];
        [_rightBtn addTarget:self action:@selector(rightBtnClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _rightBtn;
}
-(UIButton*)leftEditBtn
{
    if(!_leftEditBtn)
    {
        _leftEditBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftEditBtn.frame =CGRectMake(10, 40, 50, 50);
        [_leftEditBtn setImage:[UIImage imageNamed:@"noSelectIcon"] forState:UIControlStateNormal];
        [_leftEditBtn addTarget:self action:@selector(leftEditBtnClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _leftEditBtn;
}
-(UILabel*)middleTitleLab
{
    if (!_middleTitleLab) {
        _middleTitleLab = [[UILabel alloc]initWithFrame:CGRectMake(160, 42,100 , 30)];
        _middleTitleLab.text = @"文件列表";
        _middleTitleLab.font = [UIFont boldSystemFontOfSize:17];
        _middleTitleLab.userInteractionEnabled = NO;
        UITapGestureRecognizer * tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(middleClick)];
        [_middleTitleLab addGestureRecognizer:tap];
    }
    return _middleTitleLab;
}
-(UILabel*)bottomLable1
{
    if(!_bottomLable1)
    {
        _bottomLable1 = [[UILabel alloc] initWithFrame:CGRectMake(20, 100, 40, 20)];
        _bottomLable1.text = @"名称";
        _bottomLable1.font = [UIFont systemFontOfSize:17];
    }
    return _bottomLable1;
}
-(UILabel*)bottomLable2
{
    if(!_bottomLable2)
    {
        _bottomLable2 = [[UILabel alloc] initWithFrame:CGRectMake(260, 100, 40, 20)];
        _bottomLable2.text = @"置顶";
        _bottomLable2.font = [UIFont systemFontOfSize:17];
    }
    return _bottomLable2;
}
-(UILabel*)bottomLable3
{
    if(!_bottomLable3)
    {
        _bottomLable3 = [[UILabel alloc] initWithFrame:CGRectMake(330, 100, 40, 20)];
        _bottomLable3.text = @"拖动";
        _bottomLable3.font = [UIFont systemFontOfSize:17];
    }
    return _bottomLable3;
}
#pragma mark - ClickEvent

- (void)rightBtnClick{
    if ([_middleTitleLab.text isEqualToString:@"文件列表"]) {
            if (self.mydelegate &&[self.mydelegate respondsToSelector:@selector(navRightClickQuit)]) {
                    [self.mydelegate navRightClickQuit];
                }
    }
    else{
        [self.leftEditBtn removeFromSuperview];
    [self addSubview:self.leftBtn];
    _middleTitleLab.text = @"文件列表";
    if (self.mydelegate &&[self.mydelegate respondsToSelector:@selector(navRightClickFinish)]) {
            [self.mydelegate navRightClickFinish];
        }}
}

-(void)leftBtnClick{
    [self.leftBtn removeFromSuperview];
    [self addSubview:self.leftEditBtn];
    _middleTitleLab.text = @"删除";
    _middleTitleLab.userInteractionEnabled = YES;
    if (self.mydelegate &&[self.mydelegate respondsToSelector:@selector(navLeftClick)]) {
        [self.mydelegate navLeftClick];
    }

}

-(void)leftEditBtnClick{
    _leftEditBtn.selected = !_leftEditBtn.isSelected;
    _middleTitleLab.userInteractionEnabled = YES;
    NSString *selectAllImgStr = _leftEditBtn.selected?@"selectIcon":@"noSelectIcon";
    [_leftEditBtn setImage:[UIImage imageNamed:selectAllImgStr] forState:UIControlStateNormal];
    if (self.mydelegate &&[self.mydelegate respondsToSelector:@selector(navEditBtnClick)]) {
        [self.mydelegate navEditBtnClick];
    }
}

-(void)middleClick{
    
    if (self.mydelegate &&[self.mydelegate respondsToSelector:@selector(navMiddleClick)]) {
        [self.mydelegate navMiddleClick];
    }
}

@end
