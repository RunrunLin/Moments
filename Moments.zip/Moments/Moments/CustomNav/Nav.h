//
//  Nav.h
//  Moments
//
//  Created by jingrun lin on 2021/3/10.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol NavDelegate <NSObject>

@optional

-(void)navRightClick;
-(void)navRightLongPress;
-(void)navLeftClick;

@end

@interface Nav : UIView
{
    UIView * _navBackView;
    UIButton * _leftBtn;
    UIButton * _rightBtn;
    UILabel *  _middleTitleLab;
}

@property(nonatomic,weak) id <NavDelegate> delegate;

@property(nonatomic,strong) UIView*  navBackView;
@property(nonatomic,strong) UIButton* leftBtn;
@property(nonatomic,strong) UIButton* rightBtn;
@property(nonatomic,strong) UILabel*  middleTitleLab;

@end

NS_ASSUME_NONNULL_END
