//
//  MomentsViewController.m
//  Moments
//
//  Created by CF_Dasi on 2021/3/8.
//  Copyright © 2021年 JIAYZ. All rights reserved.
//
#import "EditViewController.h"
#import "MomentsViewController.h"

#import "MyCellTableViewCell.h"
#import "Nav.h"
#import "WeatherView.h"

#import "Masonry.h"
#import "cellModel.h"
#import "AppDelegate.h"
#import "ImgGestureRecognizer.h"

#import "AFNetworking.h"
#import "UIKit+AFNetworking.h"
#import "NSNumber+GC.h"

#define ScreenBounds           [[UIScreen mainScreen] bounds].size
#define ScreenW                 ScreenBounds.width
#define ScreenH                 ScreenBounds.height

#define APP_DOCUMENT                [NSSearchPathForDirectoriesInDomains (NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]
#define DocumentPath(path)          [APP_DOCUMENT stringByAppendingPathComponent:path]

#define lightBlueColor colorWithRed:128.0f/255.0f green:223.0f/255.0f blue:255.0f/255.0f alpha:0.75


@interface MomentsViewController ()
@property(nonatomic,strong) UIImageView* headImg;
@property(nonatomic,strong) UIImageView* headAvatar;
@property(nonatomic,strong) UIImageView* bigPic;
@property(nonatomic,strong) Nav* navView;
@property(nonatomic,strong) WeatherView* weatherView;
@property(nonatomic,strong) NSIndexPath* currentPath;
@end



@implementation MomentsViewController

#pragma mark - life cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    _arr=[[NSMutableArray alloc]init];
    [self initData];
    [self setTableView];
    
    self.headAvatar = [[UIImageView alloc] initWithFrame:CGRectMake(300, 250, 75, 75)];
    self.headAvatar.image = [UIImage imageNamed:@"avatar7"];
    self.headAvatar.layer.cornerRadius = 15.0f;
    self.headAvatar.layer.masksToBounds = YES;
    
    [self.view addSubview:_momentsTableView];
    [self.momentsTableView setTableHeaderView:self.weatherView];
    [self.weatherView addSubview:self.headAvatar];
    [self.view addSubview:self.navView];
    
    [self.momentsTableView reloadData];
    NSLocale *cale = [[NSLocale alloc]initWithLocaleIdentifier:@"zh-CN"];
    self.speechRecognizer = [[SFSpeechRecognizer alloc]initWithLocale:cale];
    _speechRecognizer.delegate = self;
}

-(void)viewWillAppear:(BOOL)animated
{
    [self initData];
    [self.momentsTableView reloadData];
}

#pragma mark - initData

-(void)initData
{
    _infoArray = [NSMutableArray array];
    _arr=[[NSMutableArray alloc]init];
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    [_arr addObjectsFromArray:app.newpost];
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    [_arr addObjectsFromArray:array];
    for(NSInteger j = 0;j < _arr.count;j++) {
        NSDictionary * dic =_arr[j];
        cellModel *model = [[cellModel alloc]init];
        
        model.userName = dic[@"userName"];
        model.userTime = dic[@"userTime"];
        model.content = dic[@"content"];
        model.imgName = dic[@"imgName"];
        
        model.img = dic[@"img"];
        model.audioTime = [dic[@"audioTime"] floatValue];
        model.filePath = dic[@"filePath"];
        [self.infoArray addObject:model];
    }
}

#pragma mark - Navigation Delegate

-(void)navRightClick
{
    [self creatActionSheet];
}

-(void)creatActionSheet
{
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction *actionCamera = [UIAlertAction actionWithTitle:@"拍摄" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
            imagePickerController.delegate = self;
        
            imagePickerController.allowsEditing = NO;
            imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            imagePickerController.cameraDevice = UIImagePickerControllerCameraDeviceRear;
            [self presentViewController:imagePickerController animated:YES completion:nil];
    }];
    
    UIAlertAction *actionPhoto = [UIAlertAction actionWithTitle:@"从相册选择图片或视频" style:UIAlertActionStyleDefault handler:  ^(UIAlertAction * _Nonnull action){
                                  UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        
                                  picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                  picker.delegate = self;
                                  picker.allowsEditing = NO;
        [self presentViewController:picker animated:YES completion:nil];}
                                  ];
    
    UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [actionSheet addAction:actionCamera];
    [actionSheet addAction:actionPhoto];
    [actionSheet addAction:actionCancel];
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}

#pragma mark - UIImagePickerControllerDelegate
// 完成图片的选取后调用的方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    EditViewController *v2 = [[EditViewController alloc]init];
    v2.modalPresentationStyle = UIModalPresentationFullScreen;
    
    v2.selectedPic1 = image;
    [self presentViewController:v2 animated:NO completion:nil];
}

// 取消选取调用的方法
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - TableView Delegate
//- (nullable UISwipeActionsConfiguration *)tableView:(UITableView *)tableView trailingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath API_AVAILABLE(ios(11.0)){
//    UIContextualAction*  action = [UIContextualAction contextualActionWithStyle:UIContextualActionStyleDestructive title:@"delete" handler:^(UIContextualAction * _Nonnull action, __kindof UIView * _Nonnull sourceView, void (^ _Nonnull completionHandler)(BOOL)) {
//        NSLog(@"!!!");
//    }];
//    UISwipeActionsConfiguration* config = [UISwipeActionsConfiguration configurationWithActions:@[action]];
//    return config;
//}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section
{
    view.tintColor = [UIColor lightBlueColor];
}

- (void)tableView:(UITableView *)tableView willDisplayFooterView:(UIView *)view forSection:(NSInteger)section {
    view.tintColor = [UIColor clearColor];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    return app.newpost.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    cellModel *model = self.infoArray[indexPath.row];
    
    NSString *content = model.content;
    
    NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:16.0]};
    CGRect contentRect = [content boundingRectWithSize:CGSizeMake(200, CGFLOAT_MAX) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:dic context:nil];
    CGFloat contentHeight;
    contentHeight = ceilf(contentRect.size.height);
    
    return 320+contentHeight;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    MyCellTableViewCell *cell = [MyCellTableViewCell cellWithTableView:tableView withIndexPath:indexPath];
    cellModel *model = [[cellModel alloc]init];
    model = self.infoArray[indexPath.row];
    
    cell.layer.affineTransform = CGAffineTransformMakeTranslation(300, 0);
    [UIView animateWithDuration:1.0f delay:0 usingSpringWithDamping: 0.5 initialSpringVelocity: 0 options:UIViewAnimationOptionCurveEaseOut animations:^{
    cell.layer.affineTransform = CGAffineTransformMakeTranslation(-300, 0);}
                     completion:^(BOOL finished) {
        cell.deleteBtn.hidden = NO;
    }];
    
    cell.imageScroll.contentSize = CGSizeMake((model.img.count+1)*120, 0);
    for (int i =0 ; i<model.img.count; i++) {
                UIImageView *cellImg = [[UIImageView alloc] init];
                [cell.imageScroll addSubview:cellImg];
        
                cellImg.userInteractionEnabled = YES;
                ImgGestureRecognizer *tap = [[ImgGestureRecognizer alloc] initWithTarget:self action:@selector(onClickImage:)];
                tap.tapImg = [UIImage imageWithContentsOfFile:model.img[i]];
                [cellImg addGestureRecognizer:tap];
        
        [cellImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(cellImg.superview.mas_top).offset(0);
            make.left.equalTo(cellImg.superview.mas_left).offset(130*i);
            make.size.mas_equalTo(CGSizeMake(120, 120));
        }];
        
        cellImg.layer.cornerRadius = 15.0f;
        cellImg.layer.masksToBounds = YES;
        cellImg.image = [UIImage imageWithContentsOfFile:model.img[i]];
    }
    
    cell.cellAudio.audioTime = model.audioTime;
    cell.cellAudio.filePath = model.filePath;
    [cell.cellAudio.progressBar setProgress:model.audioTime/10];
    
    ImgGestureRecognizer *newtap = [[ImgGestureRecognizer alloc] initWithTarget:self action:@selector(showWords:)];
    newtap.audioPath = model.filePath;
    [cell.cellAudio.progressBar addGestureRecognizer:newtap];
    cell.audioWords.text = model.audioWords;
    
    
    [cell.cellImage setImage:[UIImage imageNamed:model.imgName] forState:UIControlStateNormal];
    cell.cellName.text = model.userName;
    cell.cellText.text = model.content;
    cell.cellTime.text = model.userTime;
    
    [cell.deleteBtn addTarget:self action:@selector(deleteACell:event:) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
}
#pragma mark - Cell Delegate
-(void)deleteACell:(UIButton *)sender event:(UIEvent *)event
{
    NSSet *touches = [event allTouches];
    UITouch *touch = [touches anyObject];
    CGPoint currentTouchPosition = [touch locationInView:self.momentsTableView];
    NSIndexPath *indexPath =[self.momentsTableView indexPathForRowAtPoint:currentTouchPosition];
    
    NSFileManager *mgr = [NSFileManager defaultManager];
    cellModel* model = [[cellModel alloc] init];
    model = self.infoArray[indexPath.row];

    if ([mgr fileExistsAtPath:model.filePath]) {
        [mgr removeItemAtPath:model.filePath error:nil];
    }
    
    for (int i = 0; i<model.img.count; i++) {
        if ([mgr fileExistsAtPath:model.img[i]]) {
            [mgr removeItemAtPath:model.img[i] error:nil];
        }
    }
    
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    [app.newpost removeObjectAtIndex:indexPath.row];
    NSData *resultData = [NSJSONSerialization dataWithJSONObject:app.newpost options:NSJSONWritingPrettyPrinted error:nil];
    [resultData writeToFile:DocumentPath(@"localData.plist") atomically:YES];
    
    NSMutableArray<NSIndexPath *> *indexArr = [NSMutableArray array];
    [indexArr addObject:indexPath];
    [self.momentsTableView deleteRowsAtIndexPaths:indexArr withRowAnimation:UITableViewRowAnimationFade];
    [self initData];
    [self.momentsTableView reloadData];
}
#pragma mark - Event Response
-(void)onClickImage:(UITapGestureRecognizer *)singleTap
{
    ImgGestureRecognizer *tap = (ImgGestureRecognizer *)singleTap;
    UIView *cover = [[UIView alloc] init];
    cover.frame = CGRectMake(ScreenW/2,ScreenH/2,10,10);
    _bigPic = [[UIImageView alloc] init];
    
    _bigPic.frame = [UIScreen mainScreen].bounds;
    _bigPic.contentMode = UIViewContentModeScaleAspectFit;
    
    cover.backgroundColor = [UIColor blackColor];
    _bigPic.image = tap.tapImg;
    _bigPic.alpha = 0;
    
    [UIView animateWithDuration:0.5f animations:^{
        cover.frame =[UIScreen mainScreen].bounds;
    } completion:^(BOOL finished){
        [UIView animateWithDuration:0.25f delay:0 options:UIViewAnimationOptionCurveLinear  animations:^{
            self->_bigPic.alpha = 1.0f;
    } completion:nil];
    } ];

    
    [cover addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapCover:)]];
    [[UIApplication sharedApplication].keyWindow addSubview:cover];
    [cover addSubview:self.bigPic];
}

-(void)tapCover:(UITapGestureRecognizer*)recognizer
{
    [recognizer.view removeFromSuperview];
    self.bigPic = nil;
}

-(void)showWords:(ImgGestureRecognizer* )newtap
{
    CGPoint location = [newtap locationInView:self.momentsTableView];
    NSIndexPath *indexPath = [self.momentsTableView indexPathForRowAtPoint:location];
        
    SFSpeechURLRecognitionRequest *request = [[SFSpeechURLRecognitionRequest alloc] initWithURL:[NSURL fileURLWithPath:newtap.audioPath]];
    self.recognitionTask = [self recognitionTaskWithRequest1:request];
    self.currentPath = indexPath;
}
-(void)showDetele:(UISwipeGestureRecognizer*)leftSwipe
{
    CGPoint location = [leftSwipe locationInView:self.momentsTableView];
    if(location.x>=180)
    { NSIndexPath *indexPath = [self.momentsTableView indexPathForRowAtPoint:location];

    MyCellTableViewCell *cell = [self.momentsTableView cellForRowAtIndexPath:indexPath];
    cell.deleteBtn.hidden = NO;
    [UIView animateWithDuration:1.0f delay:0 usingSpringWithDamping: 0.5 initialSpringVelocity: 0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            cell.deleteBtn.layer.affineTransform = CGAffineTransformMakeTranslation(-90, 0);
        }completion:nil];
        NSLog(@"left");}
}
-(void)cancelDetele:(UISwipeGestureRecognizer*)rightSwipe
{
    CGPoint location = [rightSwipe locationInView:self.momentsTableView];
    if(location.x>=180)
    { NSIndexPath *indexPath = [self.momentsTableView indexPathForRowAtPoint:location];
    cellModel* model = [[cellModel alloc] init];
    model = self.infoArray[indexPath.row];

    MyCellTableViewCell *cell = [self.momentsTableView cellForRowAtIndexPath:indexPath];
    [UIView animateWithDuration:1.0f delay:0 usingSpringWithDamping: 0.5 initialSpringVelocity: 0 options:UIViewAnimationOptionCurveEaseOut animations:^{
                cell.deleteBtn.layer.affineTransform = CGAffineTransformMakeTranslation(+90, 0);
    }completion:^(BOOL finished) {
        cell.deleteBtn.hidden = YES;
    }];
        NSLog(@"right");}
}
#pragma mark- SFSpeechRecognitionTaskDelegate

-(SFSpeechRecognitionTask *)recognitionTaskWithRequest0:(SFSpeechURLRecognitionRequest *)request{

    return [self.speechRecognizer recognitionTaskWithRequest:request resultHandler:^(SFSpeechRecognitionResult * _Nullable result, NSError * _Nullable error) {
    if (!error) {
    NSLog(@"语音识别解析正确--%@", result.bestTranscription.formattedString);
    }else {
    NSLog(@"语音识别解析失败--%@", error);
    }
    }];
}

-(SFSpeechRecognitionTask *)recognitionTaskWithRequest1:(SFSpeechURLRecognitionRequest *)request{

   return [self.speechRecognizer recognitionTaskWithRequest:request delegate:self];

}

-(void)didReceiveMemoryWarning {

   [super didReceiveMemoryWarning];

}

-(void)speechRecognitionDidDetectSpeech:(SFSpeechRecognitionTask *)task
{

}

- (void)speechRecognitionTask:(SFSpeechRecognitionTask *)task didHypothesizeTranscription:(SFTranscription *)transcription
{
    
}

-(void)speechRecognitionTask:(SFSpeechRecognitionTask *)task didFinishRecognition:(SFSpeechRecognitionResult *)recognitionResult
{
    cellModel* model = [[cellModel alloc] init];
    model = self.infoArray[self.currentPath.row];
    model.audioWords = recognitionResult.bestTranscription.formattedString;
    
    [self.infoArray replaceObjectAtIndex:self.currentPath.row withObject:model];
    self.currentPath = nil;
    [self.momentsTableView reloadData];
}

-(void)speechRecognitionTaskFinishedReadingAudio:(SFSpeechRecognitionTask *)task {

}

-(void)speechRecognitionTaskWasCancelled:(SFSpeechRecognitionTask *)task {

}

-(void)speechRecognitionTask:(SFSpeechRecognitionTask *)task didFinishSuccessfully:(BOOL)successfully
{
    if (successfully) {
    NSLog(@"全部解析完毕");
                       }
}
#pragma mark - getter and setter

-(void)setTableView
{
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height) style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.backgroundColor = [UIColor lightBlueColor];
    
    tableView.userInteractionEnabled = YES;
    tableView.bounces = YES;
    UIView* blankView = [[UIView alloc] init];
    blankView.backgroundColor = [UIColor clearColor];
    UILabel* welcomeWords = [[UILabel alloc] init];
    
    welcomeWords.text = @"         写点东西\r\n记录一下你的生活";
    welcomeWords.numberOfLines = 0;
    welcomeWords.font = [UIFont fontWithName:@"MFJinHei_Noncommercial-Regular" size:30];
    welcomeWords.frame = CGRectMake(65, 50, 400, 200);
    
    [blankView addSubview:welcomeWords];
    tableView.tableFooterView = blankView;
    [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    UISwipeGestureRecognizer* leftSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(showDetele:)];
    leftSwipe.direction = UISwipeGestureRecognizerDirectionLeft;
    leftSwipe.numberOfTouchesRequired = 1;
    leftSwipe.cancelsTouchesInView = NO;
    
    UISwipeGestureRecognizer* rightSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(cancelDetele:)];
    rightSwipe.direction = UISwipeGestureRecognizerDirectionRight;
    rightSwipe.numberOfTouchesRequired = 1;
    rightSwipe.cancelsTouchesInView = NO;

    
    self.momentsTableView = tableView;
    [self.momentsTableView addGestureRecognizer:rightSwipe];
    [self.momentsTableView addGestureRecognizer:leftSwipe];
}

-(Nav*)navView
{
    if(!_navView){
        _navView = [[Nav alloc] initWithFrame:CGRectMake(0, -20, [UIScreen mainScreen].bounds.size.width, 120)];
        [_navView.rightBtn setImage:[UIImage imageNamed:@"camera"] forState:0];
        _navView.delegate = self;
    }
    return _navView;
}

-(WeatherView*)weatherView
{
    if (!_weatherView) {
        _weatherView = [[WeatherView alloc] initWithFrame:CGRectMake(0, 0, ScreenW, 300)];
    }
    return _weatherView;
}

@end
