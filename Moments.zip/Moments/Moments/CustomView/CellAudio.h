//
//  CellAudio.h
//  Moments
//
//  Created by jingrun lin on 2021/3/23.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CellAudio : UIView<AVAudioPlayerDelegate>

@property(nonatomic,strong) UIButton* mainBtn;
@property(nonatomic,strong) NSTimer* timerPlay;
@property(nonatomic,strong) UIProgressView* progressBar;

@property(nonatomic,strong) NSString* filePath;
@property(nonatomic,assign) float audioTime;
@property(nonatomic,assign) float playTime;
@property (nonatomic, strong)AVAudioPlayer *player;

@end

NS_ASSUME_NONNULL_END
