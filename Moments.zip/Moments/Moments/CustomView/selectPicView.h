//
//  selectPicView.h
//  Moments
//
//  Created by jingrun lin on 2021/3/17.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface selectPicView : UIScrollView

@property(nonatomic,strong) UIButton* addPicBtn;
@property(nonatomic,assign) int picCount;

-(void)updateLocationOfAddPicBtn;

@end



NS_ASSUME_NONNULL_END
