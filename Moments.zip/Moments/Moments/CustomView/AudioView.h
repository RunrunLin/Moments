//
//  AudioView.h
//  Moments
//
//  Created by jingrun lin on 2021/3/23.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
NS_ASSUME_NONNULL_BEGIN


@protocol AudioViewDelegate <NSObject>

@optional

-(void)startRecord;
-(void)endRecord;

@end


@interface AudioView : UIView<AVAudioRecorderDelegate,AVAudioPlayerDelegate>

@property(nonatomic,weak) id<AudioViewDelegate> mydelegate;
@property(nonatomic,strong) UIButton* mainBtn;
@property(nonatomic,strong) UIButton* cancelBtn;
@property(nonatomic,strong) UIProgressView* progressBar;

@property(nonatomic,strong) NSTimer* timer;
@property(nonatomic,strong) NSTimer* timerPlay;
@property(nonatomic,strong) NSDictionary* setting;
@property(nonatomic,strong) NSURL* url;

@property(nonatomic,strong) NSString* theFilePath;
@property(nonatomic,assign) float audioTime;
@property(nonatomic,assign) float playTime;
@property (nonatomic, strong)AVAudioRecorder *audioRecorder;

@property (nonatomic, strong)AVAudioPlayer *player;
-(NSString*)filePath;

@end

NS_ASSUME_NONNULL_END
