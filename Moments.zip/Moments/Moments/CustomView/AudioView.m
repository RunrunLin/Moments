//
//  AudioView.m
//  Moments
//
//  Created by jingrun lin on 2021/3/23.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import "AudioView.h"
#import "Masonry.h"
#import "AppDelegate.h"

#define lightGreenColor colorWithRed:179.0f/255.0f green:230.0f/255.0f blue:179.0f/255.0f alpha:0.80

@implementation AudioView

#pragma mark - init

-(instancetype)initWithFrame:(CGRect)frame{
    if(self = [super initWithFrame:frame])
    {
        [self initUI];
        [self initAudio];
        [self buildAudioViewUI];
        
    }
    return self;
}

-(void)initAudio{
    
    self.setting = [[NSDictionary alloc] init];
    self.setting =@{
    AVFormatIDKey:@(kAudioFormatAppleIMA4),//音频格式
    AVSampleRateKey:@44100.0f,//录音采样率(Hz)如：AVSampleRateKey==8000/44100/96000（影响音频的质量）
    
    AVNumberOfChannelsKey:@1,//音频通道数1或2
    AVEncoderBitDepthHintKey:@16,//线性音频的位深度8、16、24、32
    AVEncoderAudioQualityKey:@(AVAudioQualityHigh)//录音的质量
    };
    
    _url = [[NSURL alloc] init];
    _theFilePath = [[NSString alloc] init];
}

-(void)initUI{
    _mainBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self addSubview:_mainBtn];
    
    _cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self addSubview:_cancelBtn];
    
    _progressBar = [[UIProgressView alloc] init];
    [self addSubview:_progressBar];
}

-(void)buildAudioViewUI
{
#pragma mark - mainBtn
    
    [_mainBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_mainBtn.superview.mas_left).offset(20);
        make.top.equalTo(self->_mainBtn.superview.mas_top).offset(10);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(mainBtnLongPress:)];
    longPress.minimumPressDuration = 0.3;
    [_mainBtn addGestureRecognizer:longPress];
    
    [_mainBtn addTarget:self action:@selector(playAudio) forControlEvents:UIControlEventTouchUpInside];
    [_mainBtn setImage:[UIImage imageNamed:@"micro"] forState:UIControlStateNormal];

#pragma mark - progressBar
    
    [_progressBar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_mainBtn.mas_right).offset(5);
        make.top.equalTo(self->_progressBar.superview.mas_top).offset(13);
        make.size.mas_equalTo(CGSizeMake(180, 20));
    }];
    
    _progressBar.hidden = YES;
    _progressBar.progressTintColor = [UIColor lightGreenColor];
    _progressBar.trackTintColor = [UIColor clearColor];
    _progressBar.transform = CGAffineTransformMakeScale(1.0f, 0.75f);
    
#pragma mark - cancelBtn
    
    [_cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_progressBar.mas_right).offset(10);
        make.top.equalTo(self->_cancelBtn.superview.mas_top).offset(10);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    
    _cancelBtn.hidden = YES;
    [_cancelBtn addTarget:self action:@selector(deleteAudio) forControlEvents:UIControlEventTouchUpInside];
    [_cancelBtn setImage:[UIImage imageNamed:@"delete"] forState:UIControlStateNormal];
}

#pragma mark - Events Response

-(void)mainBtnLongPress:(UILongPressGestureRecognizer *)longPress
{
    switch (longPress.state) {
        case UIGestureRecognizerStateBegan:
        {
            
            if (self.mydelegate &&[self.mydelegate respondsToSelector:@selector(startRecord)]) {
                [self.mydelegate startRecord];
            }
            
            [_mainBtn setImage:[UIImage imageNamed:@"speaking"] forState:UIControlStateNormal];
            _progressBar.hidden = NO;
            _audioTime = 0;
            self.timer = [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(barProgessChangeWhenRecord) userInfo:nil repeats:YES];
            
            AVAudioSession* audioSession = [AVAudioSession sharedInstance];//得到AVAudioSession单例对象
            [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
                [audioSession setActive:YES error:nil];
            NSError*error;
            
            _url = [NSURL URLWithString:[self filePath]];
            if (!_audioRecorder) {
                self.audioRecorder= [[AVAudioRecorder alloc] initWithURL:_url settings:_setting error:&error];
            }
            
            if(self.audioRecorder) {
                self.audioRecorder.delegate=self;
            self.audioRecorder.meteringEnabled=YES;
            //设置录音时长，超过这个时间后，会暂停单位是秒
                [self.audioRecorder recordForDuration:10];
            //创建一个音频文件，并准备系统进行录制
            }
            
            if([self.audioRecorder prepareToRecord] == YES)
            { [self.audioRecorder record];}
        }
            break;
            
        case UIGestureRecognizerStateEnded:
        {
            if (self.mydelegate &&[self.mydelegate respondsToSelector:@selector(endRecord)]) {
                [self.mydelegate endRecord];
            }
            [self.audioRecorder stop];
            [self.timer invalidate];
            
            _cancelBtn.hidden = NO;
            [_mainBtn setImage:[UIImage imageNamed:@"play"] forState:UIControlStateNormal];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - playAudio
-(void)playAudio
{
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    if(_cancelBtn.isHidden == NO && app.isPlaying == NO)
    {
        app.isPlaying = YES;
        AVAudioSession* audioSession = [AVAudioSession sharedInstance];//得到AVAudioSession单例对象
        [audioSession setCategory:AVAudioSessionCategoryPlayback error:nil];
        [audioSession setActive:YES error:nil];
    
        _playTime = _audioTime;
        self.timerPlay = [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(barProgessChangeWhenPlay) userInfo:nil repeats:YES];
        NSError*error;
        
        self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:[self filePath]] error:&error];
        [self.player setNumberOfLoops:0];
        [self.player setVolume:1];
        [self.player setDelegate:self];
        
        [self.player prepareToPlay];
        [self.player play];
    }
}

-(void)audioPlayerDidFinishPlaying:(AVAudioPlayer*)player successfully:(BOOL)flag;
{
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    app.isPlaying = NO;
    [_progressBar setProgress:_audioTime/10 animated:YES];
    [self.player stop];
    [self.timerPlay invalidate];
}

#pragma mark - private method

-(void)barProgessChangeWhenRecord
{
    _audioTime +=0.05;
    [_progressBar setProgress:(_audioTime/10) animated:YES];
}

-(void)barProgessChangeWhenPlay
{
    _playTime -=0.05;
    [_progressBar setProgress:(_playTime/10) animated:YES];
}

-(void)deleteAudio
{
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    if(app.isPlaying == NO)
    {
    [_progressBar setProgress:0];
    [self.player stop];
    [self.audioRecorder deleteRecording];
    [self.timerPlay invalidate];
        
    [_mainBtn setImage:[UIImage imageNamed:@"micro"] forState:UIControlStateNormal];
    _progressBar.hidden = YES;
    _cancelBtn.hidden = YES;
    }
}

-(NSString*)filePath {
    AppDelegate* app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    NSString* path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString* symbol =[NSString stringWithFormat:@"voice%lu.caf",app.newpost.count];
    
    NSString*filePath = [path stringByAppendingPathComponent:symbol];
    _theFilePath = filePath;
    return _theFilePath;
}


@end
