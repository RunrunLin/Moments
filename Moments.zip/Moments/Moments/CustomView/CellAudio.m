//
//  CellAudio.m
//  Moments
//
//  Created by jingrun lin on 2021/3/23.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import "CellAudio.h"
#import "Masonry.h"
#import "AppDelegate.h"

#define lightGreenColor colorWithRed:179.0f/255.0f green:230.0f/255.0f blue:179.0f/255.0f alpha:0.80

@implementation CellAudio

#pragma mark - init

-(instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self initUI];
        [self buildAudioViewUI];
    }
    return self;
}

-(void)initUI
{
    _mainBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self addSubview:_mainBtn];
    _progressBar = [[UIProgressView alloc] init];
    [self addSubview:_progressBar];
}

-(void)buildAudioViewUI
{
    [_mainBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_mainBtn.superview.mas_left).offset(0);
        make.top.equalTo(self->_mainBtn.superview.mas_top).offset(0);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];

    [_mainBtn addTarget:self action:@selector(playAudio) forControlEvents:UIControlEventTouchUpInside];
    [_mainBtn setImage:[UIImage imageNamed:@"play"] forState:UIControlStateNormal];
    
    [_progressBar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_mainBtn.mas_right).offset(5);
        make.top.equalTo(self->_progressBar.superview.mas_top).offset(6);
        make.size.mas_equalTo(CGSizeMake(180, 20));
    }];
    
    _progressBar.progressTintColor = [UIColor lightGreenColor];
    _progressBar.trackTintColor = [UIColor clearColor];
    _progressBar.transform = CGAffineTransformMakeScale(1.0f, 0.75f);
}

#pragma mark - playAudio

-(void)playAudio
{
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    if(app.isPlaying == NO)
    {
        app.isPlaying = YES;
        [self.timerPlay invalidate];
    
    
    AVAudioSession* audioSession = [AVAudioSession sharedInstance];//得到AVAudioSession单例对象
    [audioSession setCategory:AVAudioSessionCategoryPlayback error:nil];
        [audioSession setActive:YES error:nil];
    
    _playTime = _audioTime;
     self.timerPlay = [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(barProgessChangeWhenPlay) userInfo:nil repeats:YES];
    NSError*error;

    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL fileURLWithPath:_filePath] error:&error];
    [self.player setNumberOfLoops:0];
    [self.player setVolume:1];
        
    [self.player setDelegate:self];
    [self.player prepareToPlay];
    [self.player play];
    }
}

-(void)audioPlayerDidFinishPlaying:(AVAudioPlayer*)player successfully:(BOOL)flag;
{
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    app.isPlaying = NO;
    [_progressBar setProgress:_audioTime/10 animated:YES];
    [self.timerPlay invalidate];
    [self.player stop];
}

#pragma mark - private method

-(void)barProgessChangeWhenPlay
{
    _playTime -=0.05;
    [_progressBar setProgress:(_playTime/10) animated:YES];
}
@end
