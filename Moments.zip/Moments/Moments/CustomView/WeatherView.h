//
//  WeatherView.h
//  Moments
//
//  Created by jingrun lin on 2021/3/22.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WeatherView : UIView

@property(nonatomic,strong) UILabel * cityName;
@property(nonatomic,strong) UILabel * temperature;
@property(nonatomic,strong) UILabel * weather;
@property(nonatomic,strong) UILabel * highestTemperature;
@property(nonatomic,strong) UIView  * backgroundView;
@property(nonatomic,strong) UILabel * lowestTemperature;
@property(nonatomic,strong) UILabel * tips;
@property(nonatomic,strong) UIImageView* weaImg;

@end

NS_ASSUME_NONNULL_END
