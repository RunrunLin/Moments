//
//  selectPicView.m
//  Moments
//
//  Created by jingrun lin on 2021/3/17.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import "selectPicView.h"
#import "Masonry.h"

@implementation selectPicView

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self)
    {
        [self buildUI];
    }
    return self;
}

-(void)buildUI
{
    _addPicBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self addSubview:self.addPicBtn];
    
    
    [_addPicBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(10);
        make.top.equalTo(self.mas_top).offset(10);
        make.size.mas_equalTo(CGSizeMake(75, 75));
    }];
    _addPicBtn.backgroundColor = [UIColor lightGrayColor];
    [_addPicBtn setTitle:@"+" forState:UIControlStateNormal];
}
-(void)updateLocationOfAddPicBtn
{
    [_addPicBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(10+self->_picCount*85);
        make.top.equalTo(self.mas_top).offset(10);
        make.size.mas_equalTo(CGSizeMake(75, 75));
    }];
    
    _addPicBtn.layer.cornerRadius = 15.0f;
    _addPicBtn.layer.masksToBounds = YES;
    _addPicBtn.backgroundColor = [UIColor lightGrayColor];
    [_addPicBtn setTitle:@"+" forState:UIControlStateNormal];
    self.contentSize = CGSizeMake(85*(_picCount+1), 0);
}
@end
