//
//  WeatherView.m
//  Moments
//
//  Created by jingrun lin on 2021/3/22.
//  Copyright © 2021 JIAYZ. All rights reserved.
//
#import "Masonry.h"
#import "AFNetworking.h"//主要用于网络请求方法
#import "UIKit+AFNetworking.h"//里面有异步加载图片的方法
#import "WeatherView.h"

#define lightBlueColor colorWithRed:128.0f/255.0f green:223.0f/255.0f blue:255.0f/255.0f alpha:0.75
#define ScreenBounds           [[UIScreen mainScreen] bounds].size
#define ScreenW                 ScreenBounds.width
#define ScreenH                 ScreenBounds.height
@implementation WeatherView

-(instancetype)initWithFrame:(CGRect)frame{
    if(self = [super initWithFrame:frame])
    {
        
        [self initUI];
        [self obtainData];
        [self buildWeatherViewUI];
        
    }
    return self;
}
-(void)initUI
{
    _backgroundView = [[UIView alloc] init];
    [self addSubview:_backgroundView];
    _cityName = [[UILabel alloc] init];
    [self addSubview:self.cityName];
    _temperature = [[UILabel alloc]init];
    [self addSubview:self.temperature];
    _highestTemperature = [[UILabel alloc]init];
    [self addSubview:self.highestTemperature];
    _lowestTemperature = [[UILabel alloc]init];
    [self addSubview:self.lowestTemperature];
    _weather = [[UILabel alloc]init];
    [self addSubview:self.weather];
    _tips = [[UILabel alloc] init];
    [self addSubview:self.tips];
    _weaImg = [[UIImageView alloc] init];
    [self addSubview:self.weaImg];
}
-(void)buildWeatherViewUI
{
#pragma mark - backgroundView
    [_backgroundView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).offset(0);
        make.left.equalTo(self.mas_left).offset(0);
        make.size.mas_equalTo(CGSizeMake(ScreenW, 300));
    }];
//    _backgroundView.backgroundColor = [UIColor lightBlueColor];
    
#pragma mark - cityName
    [_cityName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_cityName.superview.mas_left).offset(20);
        make.top.equalTo(self->_cityName.superview.mas_top).offset(100);
        make.size.mas_equalTo(CGSizeMake(220, 30));
    }];
    _cityName.textColor = [UIColor whiteColor];
    _cityName.font = [UIFont fontWithName:@"MFJinHei_Noncommercial-Regular" size:25];

#pragma mark - temperature
    [_temperature mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_temperature.superview.mas_left).offset(20);
        make.top.equalTo(self->_cityName.mas_bottom).offset(20);
        make.size.mas_equalTo(CGSizeMake(220, 30));
    }];
    _temperature.textColor = [UIColor whiteColor];
    _temperature.font = [UIFont fontWithName:@"MFJinHei_Noncommercial-Regular" size:25];
    
#pragma mark - highestTemperature
    [_highestTemperature mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_highestTemperature.superview.mas_left).offset(20);
        make.top.equalTo(self->_temperature.mas_bottom).offset(20);
        make.size.mas_equalTo(CGSizeMake(180, 30));
    }];
    _highestTemperature.textColor = [UIColor whiteColor];
    _highestTemperature.font = [UIFont fontWithName:@"MFJinHei_Noncommercial-Regular" size:23];
    
#pragma mark - lowestTemperature
    [_lowestTemperature mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_highestTemperature.mas_right).offset(5);
        make.top.equalTo(self->_temperature.mas_bottom).offset(20);
        make.size.mas_equalTo(CGSizeMake(180, 30));
    }];
    _lowestTemperature.textColor = [UIColor whiteColor];
    _lowestTemperature.font = [UIFont fontWithName:@"MFJinHei_Noncommercial-Regular" size:23];
#pragma mark - weather
    [_weather mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_cityName.mas_right).offset(20);
        make.top.equalTo(self->_cityName.superview.mas_top).offset(100);
        make.size.mas_equalTo(CGSizeMake(220, 30));
    }];
    _weather.textColor = [UIColor whiteColor];
    _weather.font = [UIFont fontWithName:@"MFJinHei_Noncommercial-Regular" size:25];
#pragma mark - weaImg
    [_weaImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_temperature.mas_right).offset(40);
        make.top.equalTo(self->_cityName.mas_bottom).offset(10);
        make.size.mas_equalTo(CGSizeMake(50, 50));
    }];
    
#pragma mark - tips
    [_tips mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self->_temperature.superview.mas_left).offset(20);
        make.top.equalTo(self->_highestTemperature.mas_bottom).offset(20);
        make.size.mas_equalTo(CGSizeMake(250, 30));
    }];
    _tips.textColor = [UIColor whiteColor];
    _tips.font = [UIFont fontWithName:@"MFJinHei_Noncommercial-Regular" size:25];
}
-(void)obtainData
{
    // 启动系统风火轮
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;

    //前面写服务器给的域名,后面拼接上需要提交的参数，假如参数是key＝1
//    NSString *url = @"https://weather.api.bdymkt.com/day";
    NSString *url = @"https://tianqiapi.com/api?version=v6&appid=12536586&appsecret=J0fE6zQ7";
    NSDictionary *parameters = @{@"city": @"深圳"};

    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];


    [manager GET:url
      parameters:parameters
//         headers:@{@"X-Bce-Signature":@"AppCode/c8e1b9ade639440da7238a8d690c96a5"}
         headers:nil
        progress:nil
         success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//            NSLog(@"responseObject = %@",responseObject);
        NSString *cityStr = [NSString stringWithFormat:@"当前城市是:%@市",responseObject[@"city"]];
        self->_cityName.text = cityStr;
        NSString *temStr =[NSString stringWithFormat:@"当前温度是:%@ ",responseObject[@"tem"]];
        self->_temperature.text = temStr;
        NSString *highestTemStr =[NSString stringWithFormat:@"最高温度是:%@ ",responseObject[@"tem1"]];
        self->_highestTemperature.text = highestTemStr;
        NSString *lowestTemStr =[NSString stringWithFormat:@"最低温度是:%@ ",responseObject[@"tem2"]];
        self->_lowestTemperature.text = lowestTemStr;
        NSString *weatherStr =[NSString stringWithFormat:@"天气:%@",responseObject[@"wea"]];
        self->_weather.text = weatherStr;
        NSString *tipsStr =[NSString stringWithFormat:@"%@",responseObject[@"air_tips"]];
        self->_tips.text = tipsStr;
        NSString *weaNameStr =[NSString stringWithFormat:@"%@",responseObject[@"wea_day_img"]];
        self->_weaImg.image = [UIImage imageNamed:weaNameStr];
        [self reloadInputViews];
        }
         failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            if (error) {
                NSLog(@"error = %@",error);
            }
        }];
}
@end
