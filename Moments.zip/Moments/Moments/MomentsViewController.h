//
//  MomentsViewController.h
//  Moments
//
//  Created by CF_Dasi on 2021/3/8.
//  Copyright © 2021年 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Speech/Speech.h>
#import "Nav.h"

NS_ASSUME_NONNULL_BEGIN

@interface MomentsViewController : UIViewController<NavDelegate,UITableViewDataSource,UITableViewDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,SFSpeechRecognizerDelegate,SFSpeechRecognitionTaskDelegate,UIScrollViewDelegate>
@property(nonatomic,retain) UITableView *momentsTableView;
@property(nonatomic,strong) NSMutableArray* infoArray;
@property (strong, nonatomic) SFSpeechRecognitionTask *recognitionTask; //语音识别任务
@property (strong, nonatomic)SFSpeechRecognizer *speechRecognizer;
@property(nonatomic,strong) NSMutableArray   * arr;

@end

NS_ASSUME_NONNULL_END
