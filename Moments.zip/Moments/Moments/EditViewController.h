//
//  EditViewController.h
//  Moments
//
//  Created by jingrun lin on 2021/3/10.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "selectPicView.h"
#import "Nav.h"
#import "AudioView.h"
NS_ASSUME_NONNULL_BEGIN



@interface EditViewController : UIViewController<NavDelegate,UITableViewDelegate,UITableViewDataSource,UIImagePickerControllerDelegate, UINavigationControllerDelegate,AudioViewDelegate,UIScrollViewDelegate>

@property(nonatomic,strong) selectPicView* picSelect;
@property(nonatomic,strong) UIImage* selectedPic1;
@property(nonatomic,strong) NSMutableArray* selectedArray;
@property(nonatomic,strong) NSMutableArray* selectedFilePath;
@end

NS_ASSUME_NONNULL_END
