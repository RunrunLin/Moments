//
//  DragViewController.h
//  Moments
//
//  Created by jingrun lin on 2021/3/12.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EditNav.h"
#import "FileCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface DragViewController : UIViewController<EditNavDelegate,fileCellDelegate,UITableViewDelegate,UITableViewDataSource>


@property(nonatomic,assign) BOOL isEdit;
@property(nonatomic,assign) BOOL isAllSelect;
@property(nonatomic,strong) NSMutableArray* infoArray;
@property(nonatomic,strong) NSMutableArray* selectArray;
@end

NS_ASSUME_NONNULL_END
