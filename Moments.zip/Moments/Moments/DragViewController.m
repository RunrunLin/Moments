//
//  DragViewController.m
//  Moments
//
//  Created by jingrun lin on 2021/3/12.
//  Copyright © 2021 JIAYZ. All rights reserved.
//

#import "DragViewController.h"
#import "EditNav.h"
#import "cellModel.h"
#import "FileCell.h"
#import "AppDelegate.h"

#define ScreenBounds           [[UIScreen mainScreen] bounds].size
#define ScreenW                 ScreenBounds.width
#define ScreenH                 ScreenBounds.height

@interface DragViewController ()
@property(nonatomic,strong) EditNav* editNav;
@property(nonatomic,retain) UITableView *dataTableView;
@end

@implementation DragViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _infoArray = [NSMutableArray array];
    [self initData];
    
    
    self.editNav.mydelegate = self;
    
    [self.view addSubview:self.editNav];
    [self.view addSubview:self.dataTableView];
    [self.view setBackgroundColor:[UIColor whiteColor]];
}

#pragma mark - Navigation Delegate

-(void)navRightClickQuit
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)navRightClickFinish
{
    _isEdit = NO;
    self.editNav.bottomLable1.frame = CGRectMake(30, 100, 40, 20);
    [self.selectArray removeAllObjects];
    [self.dataTableView reloadData];
}

-(void)navEditBtnClick
{
    if(_editNav.leftEditBtn.isSelected == YES)
    {
        [_selectArray addObjectsFromArray:_infoArray];
    }
    else{
        [_selectArray removeAllObjects];
    }
    [self.dataTableView reloadData];
}

-(void)navLeftClick
{
    _isEdit = YES;
    self.editNav.bottomLable1.frame = CGRectMake(110, 100, 40, 20);
    [self.dataTableView reloadData];
}

-(void)navMiddleClick
{
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    
    NSMutableArray<NSIndexPath *> *indexArr = [NSMutableArray array];
    for (int i = 0; i < self.selectArray.count; i++) {
        NSInteger index = [self.infoArray indexOfObject:self.selectArray[i]];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        [indexArr addObject:indexPath];
    }
    
    [self.selectArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([self.infoArray containsObject:obj] ) {
            [self.infoArray removeObject:obj];
            app.fileCount--;
        }
    }];
    
    [self.selectArray removeAllObjects];
    [self.dataTableView deleteRowsAtIndexPaths:indexArr withRowAnimation:UITableViewRowAnimationFade];
    [self.dataTableView reloadData];
}
#pragma mark - TableView Delegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infoArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 150;
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath
{
    [_infoArray exchangeObjectAtIndex:sourceIndexPath.row withObjectAtIndex:destinationIndexPath.row];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    FileCell *cell = [FileCell cellWithTableView:self.dataTableView withIndexPath:indexPath];
    
    cell.delegate = self;
    cell.fileName.text = _infoArray[indexPath.row];
    
    NSString* path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString*filePath = [path stringByAppendingPathComponent:cell.fileName.text];
    cell.audioView.filePath = filePath;
    NSLog(@"%@",cell.audioView.filePath);
    cell.audioView.audioTime = 10.0f;
    
    if (_isEdit == YES ) {
        [UIView animateWithDuration:0.25f delay:0 options:UIViewAnimationOptionCurveLinear  animations:^{
            cell.fileName.transform = CGAffineTransformMakeTranslation(80, 0);
        } completion:nil];
        
        if ([self.selectArray containsObject:cell.fileName.text]) {
            cell.isSelected = YES;
        }
        else
        {
            cell.isSelected =NO;
        }
    
        cell.selectBtn.hidden = NO;
    }
    return cell;
}

#pragma mark - Cell Delegate
//cell的selectBtn的代理方法,为了实现点击选择按钮后,selectArray同步更新
-(void)changeSelectArray:(NSString*)text
{
    [self.selectArray addObject:text];
}
//cell的StickTop的代理方法,为了实现置顶功能
-(void)setCellToTop:(NSString *)text
{
    if(text==nil)
    {
        return;
    }
    if ([self.infoArray containsObject:text]) {
        [self.infoArray removeObject:text];
        [self.infoArray insertObject:text atIndex:0];
    }
    
    NSIndexPath *bottomIndexPath=[NSIndexPath indexPathForRow:0 inSection:0];
    [self.dataTableView scrollToRowAtIndexPath:bottomIndexPath atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    [self.dataTableView reloadData];
    
    FileCell *cell = [self.dataTableView cellForRowAtIndexPath:bottomIndexPath];
    [UIView animateWithDuration:0.25f delay:0 usingSpringWithDamping: 0.5 initialSpringVelocity: 0.1 options:UIViewAnimationOptionCurveEaseOut animations:^{
    cell.layer.affineTransform = CGAffineTransformMakeTranslation(0, -50);
        
    cell.layer.transform = CATransform3DMakeScale(0.7, 0.7, 1);
    cell.layer.shadowColor = [[UIColor lightGrayColor]CGColor];
    cell.layer.shadowOpacity = 0.8;
    cell.layer.shadowOffset = CGSizeMake(10,10);
    }
     completion:^(BOOL finished){
        [UIView animateWithDuration:0.25f delay:0 options:UIViewAnimationOptionCurveLinear  animations:^{
    cell.layer.affineTransform = CGAffineTransformMakeTranslation(0, 0);
    cell.layer.transform = CATransform3DMakeScale(1, 1, 1);
    cell.layer.shadowOffset = CGSizeMake(0,0);
            
    cell.layer.shadowOpacity = 0;
    } completion:nil];
    } ];
    
}
#pragma mark - initData
-(void)initData
{
    
    _selectArray =[NSMutableArray array];
    NSString *from = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSFileManager *mgr = [NSFileManager defaultManager];
    NSArray *subpaths = [mgr contentsOfDirectoryAtPath:from error:nil];
    
    NSMutableArray *finalFiles = [subpaths mutableCopy];
    
    for (int i = 0; i<subpaths.count; i++) {
        if ([subpaths[i] containsString:@".plist"]||[subpaths[i] containsString:@".png"]) {
            [finalFiles removeObject:subpaths[i]];
        }
    }
    
    [self.infoArray addObjectsFromArray:finalFiles];
    
}

-(NSMutableArray*)selectArray
{
    if (!_selectArray) {
        _selectArray = [[NSMutableArray alloc]init];
    }
    return _selectArray;
}

#pragma mark - Events Response

- (void)longPressRecognizer:(UILongPressGestureRecognizer *)longPress{
    //获取长按的点及cell
    CGPoint location = [longPress locationInView:self.dataTableView];
    NSIndexPath *indexPath = [self.dataTableView indexPathForRowAtPoint:location];
    UIGestureRecognizerState state = longPress.state;
    static UIView *snapView = nil;
    static NSIndexPath *sourceIndex = nil;
    
    switch (state) {
        case UIGestureRecognizerStateBegan:{
            if (indexPath) {
                sourceIndex = indexPath;
                FileCell *cell = [self.dataTableView cellForRowAtIndexPath:indexPath];
                snapView = [self customViewWithTargetView:cell];
                __block CGPoint center = cell.center;
                
                snapView.center = center;
                snapView.alpha = 0.0;
                [self.dataTableView addSubview:snapView];
                
                [UIView animateWithDuration:0.1 animations:^{
                    center.y = location.y;
                    snapView.center = center;
                    snapView.transform = CGAffineTransformMakeScale(1.05, 1.05);
                    snapView.alpha = 0.5;
                    cell.alpha = 0.0;
                }];
            }
        }
            
        break;
            
        case UIGestureRecognizerStateChanged:{
            CGPoint center = snapView.center;
            center.y = location.y;
            snapView.center = center;
            FileCell *cell = [self.dataTableView cellForRowAtIndexPath:sourceIndex];
            
            cell.alpha = 0.0;
            if (indexPath && ![indexPath isEqual:sourceIndex]) {
                [_infoArray exchangeObjectAtIndex:indexPath.row withObjectAtIndex:sourceIndex.row];
                [self.dataTableView moveRowAtIndexPath:sourceIndex toIndexPath:indexPath];
                sourceIndex = indexPath;
            }
        }
            
        break;
            
        default:{
            FileCell *cell = [self.dataTableView cellForRowAtIndexPath:sourceIndex];
            [UIView animateWithDuration:0.25 animations:^{
                snapView.center = cell.center;
                snapView.transform = CGAffineTransformIdentity;
                snapView.alpha = 0.0;
                cell.alpha = 1.0;
            } completion:^(BOOL finished) {
                [snapView removeFromSuperview];
                snapView = nil;
            }];
            sourceIndex = nil;
        }
        break;
    }
}

//截取选中cell
- (UIView *)customViewWithTargetView:(UIView *)target{
    UIGraphicsBeginImageContextWithOptions(target.bounds.size, NO, 0);
    [target.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    UIView *snapshot = [[UIImageView alloc] initWithImage:image];
    snapshot.layer.masksToBounds = NO;
    snapshot.layer.cornerRadius = 0.0;
    snapshot.layer.shadowOffset = CGSizeMake(-5.0, 0.0);
    snapshot.layer.shadowRadius = 5.0;
    snapshot.layer.shadowOpacity = 0.4;
    return snapshot;
}
#pragma mark - getter and setter

-(EditNav*)editNav
{
    if (!_editNav) {
        _editNav.mydelegate = self;
        _editNav = [[EditNav alloc] initWithFrame:CGRectMake(0, 0, ScreenW, ScreenH)];
        
    }
    return _editNav;
}
-(UITableView*)dataTableView
{
    if(!_dataTableView)
    {
        _dataTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 150,ScreenW, ScreenH) style:UITableViewStylePlain];
        _dataTableView.dataSource = self;
        _dataTableView.delegate = self;

        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressRecognizer:)];
        longPress.minimumPressDuration = 0.3;
       [_dataTableView addGestureRecognizer:longPress];
        _dataTableView.backgroundColor = [UIColor whiteColor];
    }
    return _dataTableView;
}
 
@end
